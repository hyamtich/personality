# Constants for use by other modules.
# This module should not import any others, except for standard library.

START_TOKEN = u"<s>"
END_TOKEN   = u"</s>"
UNK_TOKEN   = u"<unk>"

